import { NextResponse } from 'next/server';
import { createClient } from '@supabase/supabase-js';
import { createRouteHandlerClient } from '@/lib/supabase-server';

export async function POST(request) {
  try {
    // `styles` is new: an optional { podcast: 'deep_dive', study_note: 'mcq_practice' }
    // map, keyed by the same engine ids used in `engines`. Any engine not
    // present in `styles` just uses its own default, so this is fully
    // backward compatible with old callers that never send it.
    const { knowledgeAssetId, engines = [], styles = {} } = await request.json();

    if (!knowledgeAssetId) {
      return NextResponse.json({ error: 'knowledgeAssetId is required' }, { status: 400 });
    }

    if (!engines || engines.length === 0) {
      return NextResponse.json({ error: 'At least one engine must be selected' }, { status: 400 });
    }

    // ── Supabase client setup ──────────────────────────────────────────
    // Prefer service role key (bypasses RLS); fallback to authenticated client
    const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

    let supabase;

    if (supabaseUrl && serviceRoleKey) {
      // Use service role client (bypass RLS)
      supabase = createClient(supabaseUrl, serviceRoleKey, {
        auth: { autoRefreshToken: false, persistSession: false },
      });
      console.log('🔑 Using service role client');
    } else {
      // Fallback to authenticated client (relies on RLS)
      supabase = createRouteHandlerClient();
      console.log('🔑 Using authenticated client (RLS)');
    }

    // 1. Fetch asset
    const { data: asset, error: assetError } = await supabase
      .from('knowledge_assets')
      .select('keyword')
      .eq('id', knowledgeAssetId)
      .single();

    if (assetError || !asset) {
      return NextResponse.json({ error: 'Knowledge asset not found' }, { status: 404 });
    }

    // 2. Create job
    const { data: job, error: jobError } = await supabase
      .from('generation_jobs')
      .insert({
        knowledge_asset_id: knowledgeAssetId,
        keyword: asset.keyword,
        overall_status: 'running',
        started_at: new Date().toISOString(),
      })
      .select()
      .single();

    if (jobError) {
      console.error('❌ Job creation error:', jobError);
      return NextResponse.json({ error: jobError.message }, { status: 500 });
    }

    // 3. Engine endpoints
    const engineEndpoints = {
      quiz: '/api/engines/quiz',
      boss_battle: '/api/engines/boss-battle',
      flashcard: '/api/engines/flashcards',
      study_note: '/api/engines/study-notes',
      social: '/api/engines/social',
      // The new multi-platform pipeline. This route accepts { knowledgeAssetId }
      // (platforms optional, defaults to every registered platform) and, as a
      // side effect of its own generators, renders carousels into media_files
      // and queues video scripts into video_scripts — see
      // lib/content-factory/index.js and lib/content-factory/media-attach.js.
      social_engine: '/api/content-factory/generate',
      podcast: '/api/content-engine/podcast/generate',
      blog: '/api/engines/blog',
    };

    // Engines whose endpoint accepts a `style` field. Others just ignore
    // an extra field if it's sent, but we only attach it where it means
    // something, to keep request bodies honest.
    const STYLE_AWARE_ENGINES = new Set(['podcast', 'study_note']);

    const baseUrl = request.nextUrl.origin;

    // 4. Run engines
    const results = await Promise.allSettled(
      engines.map(async (engine) => {
        const endpoint = engineEndpoints[engine];
        if (!endpoint) {
          return { engine, status: 'failed', error: `Unknown engine: ${engine}` };
        }

        try {
          const url = `${baseUrl}${endpoint}`;
          const body = { knowledgeAssetId };
          if (STYLE_AWARE_ENGINES.has(engine) && styles[engine]) {
            body.style = styles[engine];
          }
          const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
          });

          if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`HTTP ${response.status}: ${errorText}`);
          }

          const data = await response.json();
          return { engine, status: 'completed', data };
        } catch (error) {
          return { engine, status: 'failed', error: error.message };
        }
      })
    );

    // 5. Insert job items
    const jobItems = results.map((result, index) => {
      const engine = engines[index];
      let status = 'pending';
      let error = null;

      if (result.status === 'rejected') {
        status = 'failed';
        error = result.reason?.message || 'Unknown error';
      } else if (result.value.status === 'completed') {
        status = 'completed';
      } else if (result.value.status === 'failed') {
        status = 'failed';
        error = result.value.error || 'Unknown error';
      } else if (result.value.status === 'skipped') {
        status = 'skipped';
      }

      return {
        generation_job_id: job.id,
        engine,
        status,
        started_at: new Date().toISOString(),
        finished_at: status !== 'pending' ? new Date().toISOString() : null,
        error,
      };
    });

    const { error: itemsError } = await supabase
      .from('generation_job_items')
      .insert(jobItems);

    if (itemsError) {
      console.error('❌ Job items insert error:', itemsError);
    }

    // 6. Update overall status
    const completedEngines = results.filter(r => r.status === 'fulfilled' && r.value.status === 'completed');
    const failedEngines = results.filter(r => r.status === 'rejected' || (r.status === 'fulfilled' && r.value.status === 'failed'));

    let overallStatus = 'completed';
    if (failedEngines.length > 0 && completedEngines.length === 0) {
      overallStatus = 'failed';
    } else if (failedEngines.length > 0) {
      overallStatus = 'completed_with_errors';
    }

    const { error: updateError } = await supabase
      .from('generation_jobs')
      .update({
        overall_status: overallStatus,
        finished_at: new Date().toISOString(),
      })
      .eq('id', job.id);

    if (updateError) {
      console.error('❌ Job status update error:', updateError);
    }

    return NextResponse.json({
      success: true,
      jobId: job.id,
      summary: {
        total: engines.length,
        completed: completedEngines.length,
        failed: failedEngines.length,
        skipped: results.filter(r => r.status === 'fulfilled' && r.value.status === 'skipped').length,
      },
      results: results.map(r => {
        if (r.status === 'rejected') {
          return { engine: engines[results.indexOf(r)], status: 'failed', error: r.reason?.message };
        }
        return r.value;
      }),
    });
  } catch (error) {
    console.error('❌ Generation job error:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
